package DistributionTest;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ma.sqli.DecoratorPersonne.*;
import ma.sqli.FactoryPersonne.FactoryPersonne;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> ma.sqli.DecoratorPersonne
 * Date    =====> 13 nov. 2019 
 */
public class TestsDistribution {
	private ResponsableCircuit responsavleCI;
	private ResponsableCommande responsableCO;
	private Client  client ;
	private FactoryPersonne factP;
	
	@Before
	public  void initialise() {
		factP = new FactoryPersonne();
	}
	
	@Test
	public void can_not_register_same_name_twice_forDistributer() {
    responsavleCI = factP.getInstanceR("Hakim", "El imrani");

	responsavleCI.addDistributeur("Benjalal", "Nordine");
	Assert.assertEquals(false,responsavleCI.addDistributeur("Benjalal", "Nordine"));
	Assert.assertEquals(true,responsavleCI.addDistributeur("Raoui", "Younes"));

    
	}
	
	@Test 
	public void Tester_lexistance_des_produit_dans_le_stock() {
		responsavleCI = factP.getInstanceR("Hakim", "El imrani");
		responsableCO = factP.getInstance("Ahyoud", "Mohammed", responsavleCI);
		Assert.assertEquals(true, responsableCO.VerifierProduitDansStock("essence"));
		Assert.assertEquals(true, responsableCO.VerifierProduitDansStock("Gazwal"));
		Assert.assertEquals(true, responsableCO.VerifierProduitDansStock("Oeil"));
		Assert.assertEquals(true, responsableCO.VerifierProduitDansStock("Renaut"));
		Assert.assertEquals(true, responsableCO.VerifierProduitDansStock("Bm"));
		Assert.assertEquals(true, responsableCO.VerifierProduitDansStock("hunday"));


	}
	@Test
	public void lexistance_du_client() {
		responsavleCI = factP.getInstanceR("Hakim", "El imrani");
		responsableCO = factP.getInstance("Ahyoud", "Mohammed", responsavleCI);
	client = factP.getInstance("Rida", "Dhimni", "lwad zerdal", responsableCO);

      Assert.assertEquals("Rida", client.getNom());
      Assert.assertEquals("Dhimni", client.getPrenom());

	}
	
	@Test
	public void Tester_Lexistance_du_Service_clientele_pour_le_client() {
		responsavleCI = factP.getInstanceR("Hakim", "El imrani");
		responsableCO = factP.getInstance("Ahyoud", "Mohammed", responsavleCI);
		client = factP.getInstance("Rida", "Dhimni", "lwad zerdal", responsableCO);
	    Assert.assertEquals("Ahyoud",client.getResponsableCommande().getNom());
	}
	
	@Test
	public  void Tester_la_relation_entre_responsableCommande_et_responsableCircuit() {
		responsavleCI = factP.getInstanceR("Hakim", "El imrani");
		responsableCO = factP.getInstance("Ahyoud", "Mohammed", responsavleCI);

		Assert.assertEquals("Hakim", responsableCO.getResponsableCircuit().getNom());
	}
	
	@Test
	public void Tester_si_le_stock_est_initialise() {
		responsavleCI = factP.getInstanceR("Hakim", "El imrani");
		responsableCO = factP.getInstance("Ahyoud", "Mohammed", responsavleCI);
        responsableCO.getVueStock().initialiseStock();
        Assert.assertEquals(false, responsableCO.verifierStock());
	}
	
	@Test
	public void Tester_si_la_livraison_est_bien_passe() {
		responsavleCI = factP.getInstanceR("Hakim", "El imrani");
		responsableCO = factP.getInstance("Ahyoud", "Mohammed", responsavleCI);
		responsavleCI.addDistributeur("Benjalal", "Nordine");
        responsableCO.getVueStock().initialiseStock();
		client = factP.getInstance("Rida", "Dhimni", "lwad zerdal", responsableCO);
        client.demmandeCommande("essence", 2);
        client.demmandeCommande("Gazwal", 2);
        client.demmandeCommande("Oeil", 2);

        Assert.assertEquals(true, responsavleCI.verifierLivraisonByDistributeur("Gazwal"));
	}
	


}
