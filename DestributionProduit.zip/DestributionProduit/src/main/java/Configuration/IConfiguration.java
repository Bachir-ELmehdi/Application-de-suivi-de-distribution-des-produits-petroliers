package Configuration;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> Configuration
 * Date    =====> 8 nov. 2019 
 */
public interface IConfiguration {
	int NombreLivraisonMax = 3;
	int PreoriteParDefaut = 1;
	

}
