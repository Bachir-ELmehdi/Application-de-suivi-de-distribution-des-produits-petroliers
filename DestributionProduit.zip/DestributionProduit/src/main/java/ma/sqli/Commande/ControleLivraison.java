package ma.sqli.Commande;

import java.util.*;

import ma.sqli.DecoratorPersonne.*;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> Commande
 * Date    =====> 8 nov. 2019 
 */
public class ControleLivraison {
	
		private LinkedList<ICommande>  OnLivraison;
		private LinkedList<ICommande> OffLivraisonx	;
		
		public ControleLivraison() {
			OnLivraison = new LinkedList<ICommande>();
			OffLivraisonx = new LinkedList<ICommande>();
		}
		
		// ajuter Command soit de type l execution ou l annulation du commande
		public void AddCommande(ICommande lancer,ICommande annuler) {
			OnLivraison.add(lancer);
			OffLivraisonx.add(annuler);
		}
		
		//Ajouter seulement les  commandes de  lancement   
		public void AddCommandeLancer(ICommande lancer) {
			OnLivraison.add(lancer);		
		}
		
		//executer les ensembles des commandes "Livraison"
		public void executeLivraison(Distributeur dis ,int a) {
			if(Configuration.IConfiguration.NombreLivraisonMax == OnLivraison.size())
			{
				for(ICommande liv :this.OnLivraison) {
					liv.execute(dis, a);
				}
			}
			
		}
		
		//Annuler ensemble des commandes "Livraison"
		public void undoLivraison(Distributeur dis ,int a) {
			if(Configuration.IConfiguration.NombreLivraisonMax == OffLivraisonx.size())
				{for(ICommande liv:this.OffLivraisonx) {
					liv.execute(dis, a);
				}
			}
		}
	

}
