package ma.sqli.Commande;

import java.util.LinkedList;

import ma.sqli.DecoratorPersonne.Distributeur;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> Commande
 * Date    =====> 8 nov. 2019 
 */
public class lancerLivraison  implements ICommande{
    private 	Livraison livraison;

    /**
	 * 
	 */
    
    public lancerLivraison(Livraison livraison) {
    	this.livraison = livraison;
    }

	
	public void execute(Distributeur dis ,int a ) {
		// TODO Auto-generated method stub
					livraison.lancerLivraison(dis,a);
		
	}

	public void undo(Distributeur dis ,int a) {
		// TODO Auto-generated method stub
	
		livraison.AnnulerLivraison(dis);
	}

}
