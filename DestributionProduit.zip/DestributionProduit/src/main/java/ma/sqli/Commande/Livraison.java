package ma.sqli.Commande;

import ma.sqli.DecoratorPersonne.*;
import ma.sqli.DecoratorPersonne.Distributeur;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> Commande
 * Date    =====> 8 nov. 2019 
 */
public class Livraison {
	private  boolean validerLivraison= false;
	private Produit produit;
	private  int quatiteproduit;
	private Client client;
	//Constructeur
	public Livraison(Produit produit ,Client client, int quantite)
	{   this.quatiteproduit = quantite;
		this.produit = produit;
		this.client = client;
		this.validerLivraison=true;
	}
	
	//Valider un Laivraison
	public void lancerLivraison(Distributeur dis ,int a) {
  		this.validerLivraison = true;
  		dis.addLivraison(this,a);
	}
	
	//Annuler une Livraison
	public void AnnulerLivraison(Distributeur dis) {
		this.validerLivraison = false;
		dis.getCircuit().remove(this);
	}

	public Client getClient() {
		return client;
	}
	
	public Produit getProduit() {
		return produit;
	}

}
