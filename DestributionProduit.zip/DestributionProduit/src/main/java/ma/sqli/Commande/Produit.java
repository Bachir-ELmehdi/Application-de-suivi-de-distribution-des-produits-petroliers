package ma.sqli.Commande;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> Commande
 * Date    =====> 8 nov. 2019 
 */

public class Produit {
	private int idProduit;
	private static int count = 1;
	private String nomProduit;
	
	/**
	 * 
	 */
	public Produit(String nomProduit) {
		// TODO Auto-generated constructor stub
		this.nomProduit = nomProduit;
		this.idProduit=count++;
	}
	// ici la redifinition des methodes ( equals , toString) et les geters et seters
	public static int getCount() {
		return count;
	}
	
	public int getIdProduit() {
		return idProduit;
	}
	
	public String getNomProduit() {
		return nomProduit;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "ID Produit : "+idProduit+
				    "nom produit  :"+nomProduit;
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		Produit p = (Produit) obj;
		return this.getNomProduit().equals(p.getNomProduit());
	}
	
	public  boolean equals(String nom) {
		return this.nomProduit.equals(nom);
	}
	
	

}
