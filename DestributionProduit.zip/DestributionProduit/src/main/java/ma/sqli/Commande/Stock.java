package ma.sqli.Commande;


import java.util.*;

import ma.sqli.DecoratorPersonne.Distributeur;
import ma.sqli.mitier.Mitier;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> ma.sqli.Commande
 * Date    =====> 10 nov. 2019 
 */
public class Stock {
	private  HashMap<Produit,Integer> stock;
    	private Mitier mitier;

	/**
	 * 
	 */
	public Stock() {
		// TODO Auto-generated constructor stub
	stock = new HashMap<Produit, Integer>();
	mitier = new Mitier();
	}
	
	public void initialiseStock() {
		Produit produit1 = new Produit("essence");
		this.ajoutProduit(produit1, 3);
		
		Produit produit2 = new Produit("Gazwal");
		this.ajoutProduit(produit2, 5);
		
		Produit produit3 = new Produit("Oeil");
		this.ajoutProduit(produit3, 2);
		
		Produit produit4 = new Produit("Renaut");
		this.ajoutProduit(produit4, 3);
		
		Produit produit5 = new Produit("Bm");
		this.ajoutProduit(produit5, 6);
		
		Produit produit6 = new Produit("hunday");
		this.ajoutProduit(produit6, 3);
		
	}
	
	//dimunier quantite d un produit dans le stock
	public void dimunier(String nomProduit, int quantite) {
		for(Produit p : this.getStock().keySet()) {
			if(p.equals(nomProduit)) {
				int quantiteAncien = this.getStock().get(p);
				if(quantiteAncien>=quantite) {
					this.getStock().put(p, quantiteAncien-quantite);
					this.refrechStock();
	        	}else {
	        		this.getStock().put(p,0);
					this.refrechStock();
	        	}
		
			}
		}
		
	}
	
	//Actualiser le stock au cas qu un quantité d un produit devient  0
	
	public void refrechStock() {
		for(Produit p:this.getStock().keySet()) {
			if(this.getStock().get(p)==0) {
				this.getStock().put(p, 5);
			}
		}
	}
	
	public void ajoutProduit( Produit produit, int quatite) {
		stock.put(produit, quatite);
	}
	
	public void ajoutProduits(HashMap<Produit,Integer> stock)
	{
		stock.putAll(stock);
	}
	
	public boolean verifierProduitDansStock(String nomproduit ) {
	  return mitier.existeProduitDansStockByNom(stock, nomproduit);
		
	}
	
	/**
	 * @return the stock
	 */
	public HashMap<Produit, Integer> getStock() {
		return stock;
	}
	
	public void setKey(Produit produit,int quantite) {
		if(mitier.existeProduitDansStock(stock, produit)) {
			int ancien = this.stock.get(produit);
			this.stock.put(produit, ancien+quantite);
		}else {
			this.stock.put(produit, quantite);
		}
	}
	

}
