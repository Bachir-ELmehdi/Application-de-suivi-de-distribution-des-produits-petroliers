package ma.sqli.Commande;

import ma.sqli.DecoratorPersonne.Distributeur;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> Commande
 * Date    =====> 8 nov. 2019 
 */
public class AnnulerLivraison implements ICommande{
	private Livraison livraison;
	
	public  AnnulerLivraison(Livraison livraison) {
		this.livraison = livraison;
	}
	
    @Override
	public void execute(Distributeur dis ,int a) {
		// TODO Auto-generated method stub
		livraison.AnnulerLivraison( dis);
	}
    @Override
	public void undo(Distributeur dis ,int a) {
		// TODO Auto-generated method stub
		livraison.lancerLivraison(dis,a);
		
	}



}
