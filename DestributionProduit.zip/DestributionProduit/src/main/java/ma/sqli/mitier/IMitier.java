package ma.sqli.mitier;

import java.util.HashMap;
import java.util.LinkedList;

import ma.sqli.Commande.*;
import ma.sqli.DecoratorPersonne.*;;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> ma.sqli.mitier
 * Date    =====> 8 nov. 2019 
 */
public interface IMitier {
	
	//pour Responsable Commande et pour le stock
	
	public boolean existeProduitByName(HashMap<Produit, Integer> stock,String nom);
	public boolean existeQuantiteProduit(HashMap<Produit, Integer> stock, String nomProduit ,int quantite);
	public boolean existeClientByName(LinkedList<Client> clients, String nom);
	
	
	//pour Responsable Circuit
	
	public boolean existeDistribiteurByName(LinkedList<Distributeur> distribiteurs,String nom);
	public Distributeur DistributeurLibre(LinkedList<Distributeur> distributeurs);
	
	
	
	//pour Distributeur 
	
	public boolean existeLivraisonByClient(LinkedList<Livraison> livraisons,String nomClient);
	public boolean existeLivraisonByProduit(LinkedList<Livraison> livraisons,String nomProduit);
	
	//pour le client
	public int calculeDistanceInterClientDepot(Client client);
	/**
	 * @param livraisons
	 * @param nomClient
	 * @return
	 */
	boolean existeLivraisonByClient(HashMap<Livraison, Integer> livraisons, String nomClient);
	/**
	 * @param livraisons
	 * @param nomProduit
	 * @return
	 */
	boolean existeLivraisonByProduit(HashMap<Livraison, Integer> livraisons, String nomProduit);
	/**
	 * @param circuit
	 * @param nomProduit
	 * @return
	 */
	boolean existeLivraisonByNomProduit(HashMap<Livraison, Integer> circuit, String nomProduit);
	/**
	 * @param dis
	 * @param nomProduit
	 * @return
	 */
	boolean existeLivraisonByNomProduit(Distributeur dis, String nomProduit);
	

}
