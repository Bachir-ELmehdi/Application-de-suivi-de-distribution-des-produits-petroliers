package ma.sqli.mitier;

import java.util.HashMap;
import java.util.LinkedList;

import ma.sqli.Commande.Livraison;
import ma.sqli.Commande.Produit;
import ma.sqli.DecoratorPersonne.Client;
import ma.sqli.DecoratorPersonne.Distributeur;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> ma.sqli.mitier
 * Date    =====> 8 nov. 2019 
 */
public class Mitier implements IMitier{

	@Override
	public boolean existeProduitByName(HashMap<Produit, Integer> stock,String nom) {
		// TODO Auto-generated method stub
		
		Produit chekedproduit = stock.keySet().stream().
				        filter(x->x.equals(nom)).
				        findAny().
				        orElse(null);
		
		return !(chekedproduit == null);
	}

	@Override
	public boolean existeQuantiteProduit(HashMap<Produit, Integer> stock, String nomProduit ,int quantite) {
		Produit chekedproduit = stock.keySet().stream().
				                                    filter(x->x.equals(nomProduit) && stock.get(x) >=quantite).
				                                    findAny().
				                                    orElse(null);
		return !(chekedproduit == null);
	}

	@Override
	public boolean existeClientByName(LinkedList<Client> clients, String nom) {
		// TODO Auto-generated method stub
		Client chekedclient = clients.stream().
				                              filter(x->x.equals(nom)).
				                              findAny().orElse(null);
		return !(chekedclient == null);
	}
	
	
	//

	@Override
	public  boolean existeDistribiteurByName(LinkedList<Distributeur> distributeurs, String nom) {
		Distributeur chekeddistributeur = distributeurs.stream().
                filter(x->x.getNom().equals(nom)).
                findAny().orElse(null);
        return !(chekeddistributeur== null);
	}

	@Override
	public  Distributeur DistributeurLibre(LinkedList<Distributeur> distributeurs) {
		// TODO Auto-generated method stub
	    for(Distributeur dis: distributeurs) {
	    	if(dis.getCircuit().isEmpty()) {
	    		return dis;
	    	}
	    }
	    return null;
    }

	@Override
	public boolean existeLivraisonByClient(HashMap<Livraison , Integer>livraisons, String nomClient) {
		// TODO Auto-generated method stub
		
		Livraison chekedlivraison = livraisons.keySet().stream().
                filter(x->x.getClient().equals(nomClient)).
                findAny().orElse(null);
        return !(chekedlivraison== null);
	}

	@Override
	public boolean existeLivraisonByProduit(HashMap<Livraison , Integer>livraisons, String nomProduit) {
		// TODO Auto-generated method stub
		Livraison chekedlivraison = livraisons.keySet().stream().
                filter(x->x.getProduit().getNomProduit().equals(nomProduit)).
                findAny().orElse(null);
        return !(chekedlivraison== null);	}

	@Override
	public int calculeDistanceInterClientDepot(Client client) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
	//Responsable Commande
	
	public boolean existeProduitDansStock( HashMap<Produit, Integer>stock,Produit p)
	{
		Produit chekedProduit = stock.keySet().stream().
                filter(x->x.equals(p.getNomProduit())).
                findAny().orElse(null);
        return !(chekedProduit== null);
		
	}
	
	public boolean existeProduitDansStockByNom( HashMap<Produit, Integer>stock,String  nomProduit)
	{
		Produit chekedProduit = stock.keySet().stream().
                filter(x->x.getNomProduit().equals(nomProduit)).
                findAny().orElse(null);
        return !(chekedProduit== null);
		
	}
	
	
	
	public Produit getProduitByNom(HashMap<Produit, Integer>stock, String nom) {
		Produit pro= null ;
		for(Produit p: stock.keySet()) {
			if(p.getNomProduit().equals(nom)) {
				pro =p;
			}
		}
		return pro;
	}

	@Override
	public boolean existeLivraisonByNomProduit( Distributeur dis, String nomProduit) {
		Livraison chekedLivraison = dis.getCircuit().keySet().stream().
        filter(x->x.getProduit().getNomProduit().equals(nomProduit)).
        findAny().orElse(null);
        return !(chekedLivraison== null);
	}

	@Override
	public boolean existeLivraisonByClient(LinkedList<Livraison> livraisons, String nomClient) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean existeLivraisonByProduit(LinkedList<Livraison> livraisons, String nomProduit) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean existeLivraisonByNomProduit(HashMap<Livraison, Integer> circuit, String nomProduit) {
		// TODO Auto-generated method stub
		return false;
	}

//	@Override
//	public boolean existeLivraisonByProduit(LinkedList<Livraison> livraisons, String nomProduit) {
//		// TODO Auto-generated method stub
//		return false;
//	}
	
	

}
