package ma.sqli.FactoryPersonne;

import ma.sqli.DecoratorPersonne.*;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> ma.sqli.FactoryPersonne
 * Date    =====> 8 nov. 2019 
 */
public interface IFactoryPersonne {
   public Distributeur  getInstanceD(String nom,String prenom);
   public ResponsableCommande getInstance(String nom,String prenom,ResponsableCircuit res);
   public Client  getInstance(String nom,String prenom, String adress,ResponsableCommande res);
   public ResponsableCircuit  getInstanceR(String nom,String prenom);

}
