package ma.sqli.FactoryPersonne;

import ma.sqli.DecoratorPersonne.BasicPersonne;
import ma.sqli.DecoratorPersonne.Client;
import ma.sqli.DecoratorPersonne.Distributeur;
import ma.sqli.DecoratorPersonne.ResponsableCircuit;
import ma.sqli.DecoratorPersonne.ResponsableCommande;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> ma.sqli.FactoryPersonne
 * Date    =====> 8 nov. 2019 
 */
//Receiver
public class FactoryPersonne  implements IFactoryPersonne{

	@Override
	public ResponsableCircuit getInstanceR(String nom, String prenom) {
		// TODO Auto-generated method stub
		return new ResponsableCircuit(new BasicPersonne(nom,prenom));
	}

	@Override
	public ResponsableCommande getInstance(String nom, String prenom, ResponsableCircuit res) {
		// TODO Auto-generated method stub
		return  new ResponsableCommande(new BasicPersonne(nom, prenom),res);
	}

	@Override
	public Client getInstance(String nom, String prenom, String adress, ResponsableCommande res) {
		// TODO Auto-generated method stub
		return   new Client(new BasicPersonne(nom, prenom),adress,res);

	}

	@Override
	public Distributeur getInstanceD(String nom, String prenom) {
		// TODO Auto-generated method stub
		return new Distributeur(new BasicPersonne(nom, prenom));
	}
	
	

}
