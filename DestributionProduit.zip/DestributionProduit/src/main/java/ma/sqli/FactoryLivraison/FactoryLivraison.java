package ma.sqli.FactoryLivraison;

import ma.sqli.Commande.Livraison;
import ma.sqli.Commande.Produit;
import ma.sqli.DecoratorPersonne.Client;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> ma.sqli.DecoratorLivraison
 * Date    =====> 11 nov. 2019 
 */
public class FactoryLivraison implements IFactoryLivraison{

	@Override
	public Livraison getInstance(Produit produit ,Client client, int quantite)
 {
		// TODO Auto-generated method stub
		return (new Livraison(produit,client,quantite));
	}

}
