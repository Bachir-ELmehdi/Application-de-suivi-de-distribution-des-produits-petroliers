package ma.sqli.FactoryLivraison;


import ma.sqli.DecoratorPersonne.*;
import ma.sqli.Commande.*;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> ma.sqli.DecoratorLivraison
 * Date    =====> 11 nov. 2019 
 */
public interface IFactoryLivraison {
	public Livraison getInstance( Produit produit ,Client client , int quantite);

}
