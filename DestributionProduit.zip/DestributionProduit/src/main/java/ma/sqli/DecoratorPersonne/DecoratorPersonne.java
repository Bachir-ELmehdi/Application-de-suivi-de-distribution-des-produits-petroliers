package ma.sqli.DecoratorPersonne;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> DecoratorPersonne
 * Date    =====> 8 nov. 2019 
 */
public   abstract class DecoratorPersonne  implements IPersonne{
	private IPersonne personne;
	
	public  DecoratorPersonne(IPersonne personne) {
		this.personne = personne;
	}
	public String  getNom() {
		return personne.getNom();
	}
	public String 	getPrenom() {
		return personne.getPrenom();
	}
	
	
	//@Override
		public String toString() {
			// TODO Auto-generated method stub
			return personne.toString();
		}
		
 	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return personne.equals(obj);
	}
 	
	public boolean equals(String nom) {
		// TODO Auto-generated method stub
		return personne.equals(nom);
	}
	

}
