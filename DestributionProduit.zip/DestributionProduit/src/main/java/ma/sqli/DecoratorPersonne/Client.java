package ma.sqli.DecoratorPersonne;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> DecoratorPersonne
 * Date    =====> 8 nov. 2019 
 */

public class Client extends DecoratorPersonne  {
	private String address;
	private ResponsableCommande responsableCommande;
	private  int idClient;
	private  static int Count  = 0; 

	/**
	 * @param personne
	 */
	public Client(IPersonne personne ,String address ,ResponsableCommande res) {
		super(personne);
		this.responsableCommande = res;
		this.idClient = Count++;
		this.address = address;
		
		// TODO Auto-generated constructor stub
	}
	
	public void demmandeCommande(String NomProduct ,int quantite) {
		this.responsableCommande.servieClient(this, NomProduct, quantite);
	}
	
	//////////////////////----les geters-----///////////////////////
	
	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return super.getNom();
	}
	
	@Override
	public String getPrenom() {
		// TODO Auto-generated method stub
		return super.getPrenom();
		
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+" Id Client : "+idClient;
	}
	

	public int getIdClient() {
		return idClient;
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return this.equals(obj);
	}
	
	/**
	 * @return the responsableCommande
	 */
	public ResponsableCommande getResponsableCommande() {
		return responsableCommande;
	}
	

}
