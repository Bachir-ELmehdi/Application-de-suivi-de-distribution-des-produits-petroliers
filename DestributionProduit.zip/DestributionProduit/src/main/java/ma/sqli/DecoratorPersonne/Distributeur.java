package ma.sqli.DecoratorPersonne;

import java.util.*;


import ma.sqli.Commande.Livraison;
import ma.sqli.mitier.Mitier;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> DecoratorPersonne
 * Date    =====> 8 nov. 2019 
 */

public class  Distributeur extends DecoratorPersonne  {
	
   private HashMap<Livraison , Integer> circuit ;
   private Mitier mitier;

	/**
	 * @param personne
	 */
	public Distributeur(IPersonne personne) {
		super(personne);
		mitier = new Mitier();
		// TODO Auto-generated constructor stub
		circuit = new HashMap<>();
	}
	
	//Ajouter livraison
	public void addLivraison(Livraison livraion, int preorite) {
		circuit.put(livraion, preorite);
	}
	
	//supprimer la livraison
	public void removeLivraison(Livraison livraison) {
		circuit.remove(livraison);
	}
	
	public boolean VerifierExisteLivraison(String nomClient) {
		return	mitier.existeLivraisonByClient(circuit, nomClient);
		}
	
	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return super.getNom();
	}
	
	@Override
	public String getPrenom() {
		// TODO Auto-generated method stub
		return super.getPrenom();
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+"Role : Distributeur";
	}

	
	public HashMap<Livraison, Integer> getCircuit() {
		return circuit;
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return this.equals(obj);
	}
	
	@Override
		public boolean equals(String nom) {
			// TODO Auto-generated method stub
			return this.equals(nom);
		}

	

	

}
