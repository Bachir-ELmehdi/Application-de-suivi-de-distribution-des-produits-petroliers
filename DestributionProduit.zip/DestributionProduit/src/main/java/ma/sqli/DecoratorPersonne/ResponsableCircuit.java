package ma.sqli.DecoratorPersonne;

import java.util.*;
import Configuration.*;
import ma.sqli.Commande.ControleLivraison;
import ma.sqli.Commande.Livraison;
import ma.sqli.Commande.lancerLivraison;
import ma.sqli.mitier.*;

import ma.sqli.FactoryPersonne.FactoryPersonne;

public  class ResponsableCircuit  extends DecoratorPersonne{
      private LinkedList<Distributeur> distributeurs;
      private Mitier mitier ;
      private ControleLivraison control;
      private FactoryPersonne factP ;

	/**
	 * @param personne
	 */
      
	public ResponsableCircuit(IPersonne personne) {
		super(personne);
		distributeurs= new LinkedList<Distributeur>();
		mitier = new Mitier();
		control = new ControleLivraison();
		factP = new FactoryPersonne();
		// TODO Auto-generated constructor stub
	}
	
	//Recuperer la livraison a travers responsable  Commande
	public void recupererLivraison(Livraison livraison) {
		System.out.println(livraison.getProduit());
		this.gereLivraison(livraison);
	}
	
	//gere Les livraisons qui viens de le responsable commande en utilisant  Le control Livraison
	public void  gereLivraison(Livraison livraison) {
		lancerLivraison lancer = new lancerLivraison(livraison);
		control.AddCommandeLancer(lancer);		
		control.executeLivraison(mitier.DistributeurLibre(distributeurs),IConfiguration.PreoriteParDefaut);

	}
	//Verifier l affectation du livraison just pour le premier Distributeur
	public boolean verifierLivraisonByDistributeur(String nomProduit) {
	  return mitier.existeLivraisonByNomProduit(this.getDistributeurs().get(0),nomProduit);
	}
	
	
	
	
	public boolean   addDistributeur(String nom , String prenom) {
		Distributeur distributeur = factP.getInstanceD(nom, prenom);
		boolean test = mitier.existeDistribiteurByName(distributeurs,nom);
        if (!test){
			this.distributeurs.add(distributeur);
		}
		return !(test);
	}
	
	public boolean existeDistributeur(String nomdistributeur) {
		return mitier.existeDistribiteurByName(distributeurs, nomdistributeur);
	}
	


	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return super.getNom();
	}
	
	@Override
	public String getPrenom() {
		// TODO Auto-generated method stub
		return super.getPrenom();
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+" Role :  Responsable Circuit";
	}
	
	@Override
	public boolean equals(String nom) {
		// TODO Auto-generated method stub
		return this.equals(nom);
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}
	/**
	 * @return the distributeurs
	 */
	public LinkedList<Distributeur> getDistributeurs() {
		return distributeurs;
	}
	

}
