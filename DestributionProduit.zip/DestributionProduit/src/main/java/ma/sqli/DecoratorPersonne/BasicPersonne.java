package ma.sqli.DecoratorPersonne;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> DecoratorPersonne
 * Date    =====> 8 nov. 2019 
 */
public class BasicPersonne implements IPersonne{
	private String nom;
	private String prenom;
	
	/**
	 * 
	 */
	public BasicPersonne(String nom,String prenom) {
		// TODO Auto-generated constructor stub
		this.nom = nom;
		this.prenom = prenom;
	}
	
	@Override
	public String  getNom() {
		// TODO Auto-generated method stub
		return this.nom;
		
	}
	@Override
	
	public String getPrenom() {
		// TODO Auto-generated method stub
		return this.prenom;
		
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Nom : "+nom+" Prenom : "+prenom;
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		BasicPersonne p = (BasicPersonne)obj;
		return this.getNom().equals(p.getNom());
	}
	
	public boolean equals(String nom) {
		return this.getNom().equals(nom);
		
	    }
}
