package ma.sqli.DecoratorPersonne;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> DecoratorPersonne
 * Date    =====> 8 nov. 2019 
 */
public interface IPersonne {
	public String getNom();
    public 	String  getPrenom();
    public String toString();

	public boolean equals(Object obj);

	public boolean equals(String nom);
	


}
