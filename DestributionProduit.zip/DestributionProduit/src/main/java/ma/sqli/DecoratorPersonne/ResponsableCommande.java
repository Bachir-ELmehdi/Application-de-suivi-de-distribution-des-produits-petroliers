package ma.sqli.DecoratorPersonne;

import java.util.HashMap;

import ma.sqli.Commande.Livraison;
import ma.sqli.Commande.Produit;
import ma.sqli.Commande.Stock;
import ma.sqli.FactoryLivraison.FactoryLivraison;
import ma.sqli.mitier.Mitier;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> DestributionProduit
 * Package =====> DecoratorPersonne
 * Date    =====> 8 nov. 2019 
 */
public class ResponsableCommande extends DecoratorPersonne {
	private FactoryLivraison factL;
	private Stock vueStock ;
	private ResponsableCircuit responsableCircuit;
	private Mitier mitier;
//	HashMap<Produit,Integer> stock;
	

	/**
	 * @param personne
	 */
	
	public ResponsableCommande(IPersonne personne,ResponsableCircuit res) {
		super(personne);
		this.responsableCircuit = res;
		this.factL = new FactoryLivraison();
		this.mitier = new Mitier();
		this.vueStock = new Stock();
		this.vueStock.initialiseStock();
		// TODO Auto-generated constructor stub
	}
	
	//creation d un livraison
	 public Livraison creatLivraison(Produit produit,Client client, int quantite) {
		 return factL.getInstance(produit, client,quantite);
	 }
	 
	 //Assurer La srvice Clientèle a travers l execution du livraison
	 public void servieClient(Client client,String nomProduit,int quantite) {
		 if(mitier.existeProduitDansStockByNom(vueStock.getStock(),nomProduit)) {
				 this.vueStock.dimunier(nomProduit,quantite);		
				 Produit p = mitier.getProduitByNom(vueStock.getStock(), nomProduit);
			   	 Livraison  livraison= creatLivraison(p, client, quantite);
			   	 this.responsableCircuit.recupererLivraison(livraison);
		 }
	 }
	 
	 //existance du Produit Dans le stock
	 public boolean VerifierProduitDansStock(String nomproduit) {
    	return 	this.vueStock.verifierProduitDansStock(nomproduit);
	 }
	 
	 
	 //remplissage du stock une foie pour tout
	 public void RemplissageDuStock(HashMap<Produit,Integer> stock) {
		 vueStock.ajoutProduits(stock);
	 }
	 
	 //Verifier si le stock est  vide ou non
	 public boolean verifierStock() {
		 return this.vueStock.getStock().isEmpty();
	 }
	 
	 //L ajout du produit dans le stock qui est gere par Le responsable du Commande
	 public void  ajoutProduit(Produit produit , int quantite) {
	   vueStock.setKey(produit, quantite);
	 }
	 
	 //-----les Geters et seters
	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return super.getNom();
	}
	// ici il ya la redifinition des methodes (equals,toString), et les geters et les seters
	
	@Override
	public String getPrenom() {
		// TODO Auto-generated method stub
		return super.getPrenom();
	}
	@Override
	
	//redifinition toString
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+" Role : "+"Responsable Commande";
	}
	//redifinition de L equals
	@Override
	public boolean equals(String nom) {
		// TODO Auto-generated method stub
		return this.equals(nom);
	}
	/**
	 * @return the vueStock
	 */
	public Stock getVueStock() {
		return vueStock;
	}
	
	/**
	 * @return the responsableCircuit
	 */
	public ResponsableCircuit getResponsableCircuit() {
		return responsableCircuit;
	}
	
	
}
